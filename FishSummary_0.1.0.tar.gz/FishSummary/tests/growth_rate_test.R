test_that("growth_rate_works", {expect_that(growth_rate(-.497,0.1656,0.08588,-.004266,14.3)>0, is_true())})
