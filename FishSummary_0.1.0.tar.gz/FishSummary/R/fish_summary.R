fish_summary = function(price,catch, plot = F){
  most_fish = list(colnames(catch), rownames(catch)[apply(catch, 2, which.max)])
  total_rev = sum(price[,1] * catch)
  loc_rev = price[,1] * catch
  loc_rev = colSums(loc_rev)
  loc_rev_df = data.frame(loc_rev)
  loc_rev_df$location = c(rownames(loc_rev_df))
  if (plot) {
    lb = sprintf("The total revenue is %d dollars", total_rev)
    p = ggplot(loc_rev_df, aes(location, loc_rev, fill=location))+geom_col()+
      labs(y="revenue in dollars")+annotate("text", x=2, y=5000, label=lb, col="red")
  }
  else p=NULL
  return(list(MostFrequent = most_fish, TotalRevenue = total_rev, Revenue_by_Location = loc_rev_df, plot = p))
}
