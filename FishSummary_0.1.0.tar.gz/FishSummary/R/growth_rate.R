growth_rate = function(a,b,c,d,temp){
  G <- (a+b*temp+c*temp^2+d*temp^3)
  return(G)
}
