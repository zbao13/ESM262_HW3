test_that("fish_summary_works",{expect_that(fish_summary(fish_price_1,fish_catch_1)$TotalRevenue > 5000, is_true())})
